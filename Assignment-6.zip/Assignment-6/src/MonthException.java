import java.util.Scanner;

public class MonthException {
    public static int validateMonth(String month) {
        boolean done = false;
        while (!done) {
            try {
                if (Integer.valueOf(month) <= 12 && Integer.valueOf(month) >= 1) {
                    done = true;
                } else {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid month. Reenter a valid month:");
                Scanner scanner = new Scanner(System.in);
                month = scanner.next();
            }
        }
        return Integer.valueOf(month);
    }
}
