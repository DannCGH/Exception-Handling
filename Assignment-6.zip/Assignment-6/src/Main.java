import java.time.Year;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter date to parse: (MM/DD/YYYY format)");
        String input = scanner.next();

        StringTokenizer st = new StringTokenizer(input, "/");

        int month = 0;
        String dayTemp = "";
        int year = 0;
        int day = 0;

        String monthInput = "";
        String dayInput = "";
        String yearInput = "";

        boolean done = false;
        while (!done) {
            try {
                if (monthInput != "") {
                    month = MonthException.validateMonth(monthInput);
                    done = true;
                } else {
                    month = MonthException.validateMonth(st.nextToken());
                    done = true;
                }
            } catch (NoSuchElementException e) {
                System.out.println("No month entered. Reenter a valid month:");
                monthInput = scanner.next();
            }
        }

        done = false;
        while (!done) {
            try {
                if (dayInput != "") {
                    dayTemp = dayInput;
                    done = true;
                } else {
                    dayTemp = st.nextToken();
                    done = true;
                }
            } catch (NoSuchElementException e) {
                System.out.println("No day entered. Reenter a valid day:");
                dayInput = scanner.next();
            }
        }

        done = false;
        while (!done) {
            try {
                if (yearInput != "") {
                    year = YearException.validateYear(yearInput);
                    done = true;
                } else {
                    year = YearException.validateYear(st.nextToken());
                    done = true;
                }
            } catch (NoSuchElementException e) {
                System.out.println("No year entered. Reenter a valid year:");
                yearInput = scanner.next();
            }
        }

        day = DayException.validateDay(dayTemp, month, year);

        Date date = new Date(month, day, year);

        System.out.println("Parsed date: " + date.monthString(date.getMonth()) + " " + date.getDay() + ", " + date.getYear());

    }
}