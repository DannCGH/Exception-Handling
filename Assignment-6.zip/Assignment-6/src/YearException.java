import java.util.Scanner;

public class YearException {
    public static int validateYear(String year) {
        boolean done = false;
        while (!done) {
            try {
                if (Integer.valueOf(year) <= 3000 && Integer.valueOf(year) >= 1000) {
                    done = true;
                } else {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid year. Reenter a valid year:");
                Scanner scanner = new Scanner(System.in);
                year = scanner.next();
            }
        }
        return Integer.valueOf(year);
    }
}
