import java.util.Scanner;

public class DayException {
    public static int validateDay(String day, int month, int year) {
        boolean done = false;
        int daysInMonth = 0;
        switch (month) {
            case (4):
            case (6):
            case (9):
            case (11):
                daysInMonth = 30;
            case (1):
            case (3):
            case (5):
            case (7):
            case (8):
            case (10):
            case (12):
                daysInMonth = 31;
            case (2):
                daysInMonth = 28;
                if (year % 4 == 0) {
                    daysInMonth++;
                }
        }
        while (!done) {
            try {
                if (Integer.valueOf(day) <= daysInMonth && Integer.valueOf(day) >= 1) {
                    done = true;
                } else {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid day. Reenter a valid day:");
                Scanner scanner = new Scanner(System.in);
                day = scanner.next();
            }
        }
        return Integer.valueOf(day);
    }
}
